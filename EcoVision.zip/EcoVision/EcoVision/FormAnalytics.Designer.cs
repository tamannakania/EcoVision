﻿namespace EcoVision
{
    partial class FormAnalytics
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            lblHeading = new Label();
            lblto = new Label();
            cmbFilterCity = new ComboBox();
            dtpFrom = new DateTimePicker();
            dtpTo = new DateTimePicker();
            btnLoadAnalytics = new Button();
            chartAQITrend = new System.Windows.Forms.DataVisualization.Charting.Chart();
            chartPollutants = new System.Windows.Forms.DataVisualization.Charting.Chart();
            chartPie = new System.Windows.Forms.DataVisualization.Charting.Chart();
            btnBack = new Button();
            lblSelectCity = new Label();
            panel1 = new Panel();
            lblMaxAQI = new Label();
            lblRecords = new Label();
            lblMinAQI = new Label();
            lblAvgAQI = new Label();
            ((System.ComponentModel.ISupportInitialize)chartAQITrend).BeginInit();
            ((System.ComponentModel.ISupportInitialize)chartPollutants).BeginInit();
            ((System.ComponentModel.ISupportInitialize)chartPie).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // lblHeading
            // 
            lblHeading.AutoSize = true;
            lblHeading.Font = new Font("Segoe UI Symbol", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblHeading.Location = new Point(78, 9);
            lblHeading.Name = "lblHeading";
            lblHeading.Size = new Size(685, 41);
            lblHeading.TabIndex = 0;
            lblHeading.Text = "Advanced Environmental Analytics and Insights";
            // 
            // lblto
            // 
            lblto.AutoSize = true;
            lblto.BackColor = Color.FromArgb(255, 192, 192);
            lblto.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblto.Location = new Point(582, 70);
            lblto.Name = "lblto";
            lblto.Size = new Size(26, 23);
            lblto.TabIndex = 2;
            lblto.Text = "to";
            // 
            // cmbFilterCity
            // 
            cmbFilterCity.BackColor = SystemColors.ActiveCaption;
            cmbFilterCity.FormattingEnabled = true;
            cmbFilterCity.Items.AddRange(new object[] { "Bangalore", "Delhi", "Mumbai", "Chennai", "Hyderabad", "Kolkata", "Pune", "Ahmedabad" });
            cmbFilterCity.Location = new Point(12, 91);
            cmbFilterCity.Name = "cmbFilterCity";
            cmbFilterCity.Size = new Size(271, 28);
            cmbFilterCity.TabIndex = 5;
            // 
            // dtpFrom
            // 
            dtpFrom.CalendarFont = new Font("Verdana", 10.2F);
            dtpFrom.Location = new Point(302, 70);
            dtpFrom.Name = "dtpFrom";
            dtpFrom.Size = new Size(250, 27);
            dtpFrom.TabIndex = 6;
            // 
            // dtpTo
            // 
            dtpTo.CalendarFont = new Font("Verdana", 10.2F);
            dtpTo.Location = new Point(631, 70);
            dtpTo.Name = "dtpTo";
            dtpTo.Size = new Size(250, 27);
            dtpTo.TabIndex = 7;
            // 
            // btnLoadAnalytics
            // 
            btnLoadAnalytics.BackColor = Color.FromArgb(255, 224, 192);
            btnLoadAnalytics.FlatStyle = FlatStyle.Flat;
            btnLoadAnalytics.Location = new Point(349, 135);
            btnLoadAnalytics.Name = "btnLoadAnalytics";
            btnLoadAnalytics.Size = new Size(195, 29);
            btnLoadAnalytics.TabIndex = 8;
            btnLoadAnalytics.Text = "LOAD ANALYTICS";
            btnLoadAnalytics.UseVisualStyleBackColor = false;
            btnLoadAnalytics.Click += btnLoadAnalytics_Click;
            // 
            // chartAQITrend
            // 
            chartAQITrend.BorderlineColor = Color.Transparent;
            chartArea1.Name = "ChartArea1";
            chartAQITrend.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            chartAQITrend.Legends.Add(legend1);
            chartAQITrend.Location = new Point(12, 347);
            chartAQITrend.Name = "chartAQITrend";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            chartAQITrend.Series.Add(series1);
            chartAQITrend.Size = new Size(271, 287);
            chartAQITrend.TabIndex = 9;
            chartAQITrend.Text = "AQI Trend";
            // 
            // chartPollutants
            // 
            chartPollutants.BorderlineColor = Color.Transparent;
            chartArea2.Name = "ChartArea1";
            chartPollutants.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            chartPollutants.Legends.Add(legend2);
            chartPollutants.Location = new Point(302, 347);
            chartPollutants.Name = "chartPollutants";
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            chartPollutants.Series.Add(series2);
            chartPollutants.Size = new Size(279, 289);
            chartPollutants.TabIndex = 10;
            chartPollutants.Text = "Pollutant Comparison";
            // 
            // chartPie
            // 
            chartPie.BorderlineColor = Color.Transparent;
            chartArea3.Name = "ChartArea1";
            chartPie.ChartAreas.Add(chartArea3);
            legend3.Name = "Legend1";
            chartPie.Legends.Add(legend3);
            chartPie.Location = new Point(600, 347);
            chartPie.Name = "chartPie";
            series3.ChartArea = "ChartArea1";
            series3.Legend = "Legend1";
            series3.Name = "Series1";
            chartPie.Series.Add(series3);
            chartPie.Size = new Size(281, 289);
            chartPie.TabIndex = 11;
            chartPie.Text = "Pollution Breakdown";
            // 
            // btnBack
            // 
            btnBack.BackColor = Color.FromArgb(255, 224, 192);
            btnBack.FlatStyle = FlatStyle.Flat;
            btnBack.Location = new Point(349, 654);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(195, 29);
            btnBack.TabIndex = 13;
            btnBack.Text = "BACK TO DASHBOARD";
            btnBack.UseVisualStyleBackColor = false;
            btnBack.Click += btnBack_Click;
            // 
            // lblSelectCity
            // 
            lblSelectCity.AutoSize = true;
            lblSelectCity.BackColor = Color.FromArgb(255, 128, 128);
            lblSelectCity.Font = new Font("SimSun-ExtG", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblSelectCity.Location = new Point(78, 67);
            lblSelectCity.Name = "lblSelectCity";
            lblSelectCity.Size = new Size(118, 18);
            lblSelectCity.TabIndex = 14;
            lblSelectCity.Text = "Select City";
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(0, 0, 64);
            panel1.Controls.Add(lblMaxAQI);
            panel1.Controls.Add(lblRecords);
            panel1.Controls.Add(lblMinAQI);
            panel1.Controls.Add(lblAvgAQI);
            panel1.Location = new Point(12, 187);
            panel1.Name = "panel1";
            panel1.Size = new Size(857, 125);
            panel1.TabIndex = 15;
            // 
            // lblMaxAQI
            // 
            lblMaxAQI.AutoSize = true;
            lblMaxAQI.BackColor = Color.FromArgb(255, 192, 192);
            lblMaxAQI.Location = new Point(40, 89);
            lblMaxAQI.Name = "lblMaxAQI";
            lblMaxAQI.Size = new Size(114, 20);
            lblMaxAQI.TabIndex = 3;
            lblMaxAQI.Text = "Highest AQI: ---";
            // 
            // lblRecords
            // 
            lblRecords.AutoSize = true;
            lblRecords.BackColor = Color.FromArgb(255, 192, 192);
            lblRecords.Location = new Point(445, 89);
            lblRecords.Name = "lblRecords";
            lblRecords.Size = new Size(87, 20);
            lblRecords.TabIndex = 2;
            lblRecords.Text = "Records: ---";
            // 
            // lblMinAQI
            // 
            lblMinAQI.AutoSize = true;
            lblMinAQI.BackColor = Color.FromArgb(255, 192, 192);
            lblMinAQI.Location = new Point(445, 25);
            lblMinAQI.Name = "lblMinAQI";
            lblMinAQI.Size = new Size(109, 20);
            lblMinAQI.TabIndex = 1;
            lblMinAQI.Text = "Lowest AQI: ---";
            // 
            // lblAvgAQI
            // 
            lblAvgAQI.AutoSize = true;
            lblAvgAQI.BackColor = Color.FromArgb(255, 192, 192);
            lblAvgAQI.Location = new Point(40, 25);
            lblAvgAQI.Name = "lblAvgAQI";
            lblAvgAQI.Size = new Size(118, 20);
            lblAvgAQI.TabIndex = 0;
            lblAvgAQI.Text = "Average AQI: ---";
            // 
            // FormAnalytics
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlDark;
            ClientSize = new Size(893, 708);
            Controls.Add(panel1);
            Controls.Add(lblSelectCity);
            Controls.Add(btnBack);
            Controls.Add(chartPie);
            Controls.Add(chartPollutants);
            Controls.Add(chartAQITrend);
            Controls.Add(btnLoadAnalytics);
            Controls.Add(dtpTo);
            Controls.Add(dtpFrom);
            Controls.Add(cmbFilterCity);
            Controls.Add(lblto);
            Controls.Add(lblHeading);
            Name = "FormAnalytics";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Pollution Analytics Dashboard – Data Visualization Center";
            Load += FormAnalytics_Load;
            ((System.ComponentModel.ISupportInitialize)chartAQITrend).EndInit();
            ((System.ComponentModel.ISupportInitialize)chartPollutants).EndInit();
            ((System.ComponentModel.ISupportInitialize)chartPie).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblHeading;
        private Label lblto;
        private ComboBox cmbFilterCity;
        private DateTimePicker dtpFrom;
        private DateTimePicker dtpTo;
        private Button btnLoadAnalytics;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartAQITrend;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartPollutants;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartPie;
        private Button btnBack;
        private Label lblSelectCity;
        private Panel panel1;
        private Label lblMaxAQI;
        private Label lblRecords;
        private Label lblMinAQI;
        private Label lblAvgAQI;
    }
}