﻿namespace EcoVision
{
    partial class FormAlerts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblHeading = new Label();
            btnCheck = new Button();
            lblAlertStatus = new Label();
            dgvAlerts = new DataGridView();
            btnBack = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvAlerts).BeginInit();
            SuspendLayout();
            // 
            // lblHeading
            // 
            lblHeading.AutoSize = true;
            lblHeading.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblHeading.Location = new Point(150, 9);
            lblHeading.Name = "lblHeading";
            lblHeading.Size = new Size(496, 41);
            lblHeading.TabIndex = 0;
            lblHeading.Text = "Smart Environmental Alert Center";
            // 
            // btnCheck
            // 
            btnCheck.BackColor = Color.FromArgb(255, 192, 192);
            btnCheck.FlatStyle = FlatStyle.Popup;
            btnCheck.Font = new Font("Times New Roman", 12F, FontStyle.Bold);
            btnCheck.Location = new Point(205, 72);
            btnCheck.Name = "btnCheck";
            btnCheck.Size = new Size(387, 29);
            btnCheck.TabIndex = 1;
            btnCheck.Text = "CHECK FOR POLLUTION SPIKES";
            btnCheck.UseVisualStyleBackColor = false;
            btnCheck.Click += btnCheck_Click;
            // 
            // lblAlertStatus
            // 
            lblAlertStatus.AutoSize = true;
            lblAlertStatus.FlatStyle = FlatStyle.Flat;
            lblAlertStatus.Font = new Font("Tahoma", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAlertStatus.Location = new Point(248, 120);
            lblAlertStatus.Name = "lblAlertStatus";
            lblAlertStatus.Size = new Size(263, 22);
            lblAlertStatus.TabIndex = 2;
            lblAlertStatus.Text = "Alert Status: No Critical Risk";
            // 
            // dgvAlerts
            // 
            dgvAlerts.BackgroundColor = SystemColors.ActiveCaption;
            dgvAlerts.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvAlerts.Location = new Point(12, 160);
            dgvAlerts.Name = "dgvAlerts";
            dgvAlerts.RowHeadersWidth = 51;
            dgvAlerts.Size = new Size(776, 172);
            dgvAlerts.TabIndex = 3;
            dgvAlerts.CellContentClick += dataGridView1_CellContentClick;
            // 
            // btnBack
            // 
            btnBack.BackColor = Color.FromArgb(255, 192, 192);
            btnBack.FlatStyle = FlatStyle.Popup;
            btnBack.Font = new Font("Times New Roman", 12F, FontStyle.Bold);
            btnBack.Location = new Point(259, 365);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(278, 29);
            btnBack.TabIndex = 5;
            btnBack.Text = "BACK TO DASHBOARD";
            btnBack.UseVisualStyleBackColor = false;
            btnBack.Click += btnBack_Click;
            // 
            // FormAlerts
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlDark;
            ClientSize = new Size(800, 450);
            Controls.Add(btnBack);
            Controls.Add(dgvAlerts);
            Controls.Add(lblAlertStatus);
            Controls.Add(btnCheck);
            Controls.Add(lblHeading);
            Name = "FormAlerts";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Pollution Alerts – Environmental Risk Monitoring";
            Load += FormAlerts_Load;
            ((System.ComponentModel.ISupportInitialize)dgvAlerts).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblHeading;
        private Button btnCheck;
        private Label lblAlertStatus;
        private DataGridView dgvAlerts;
        private Button btnBack;
    }
}