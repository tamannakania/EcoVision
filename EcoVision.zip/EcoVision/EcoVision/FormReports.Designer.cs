﻿namespace EcoVision
{
    partial class FormReports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblHeading = new Label();
            cmbReportCity = new ComboBox();
            cmbMonth = new ComboBox();
            btnGenerate = new Button();
            btnExportPDF = new Button();
            btnBack = new Button();
            rtbReport = new RichTextBox();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // lblHeading
            // 
            lblHeading.AutoSize = true;
            lblHeading.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblHeading.Location = new Point(69, 19);
            lblHeading.Name = "lblHeading";
            lblHeading.Size = new Size(709, 41);
            lblHeading.TabIndex = 0;
            lblHeading.Text = "Sustainability and Environmental Impact Reports";
            lblHeading.Click += lblHeading_Click;
            // 
            // cmbReportCity
            // 
            cmbReportCity.Font = new Font("Tahoma", 12F);
            cmbReportCity.FormattingEnabled = true;
            cmbReportCity.Items.AddRange(new object[] { "Bangalore", "Delhi", "Mumbai", "Chennai", "Hyderabad", "Kolkata", "Pune", "Ahmedabad" });
            cmbReportCity.Location = new Point(144, 129);
            cmbReportCity.Name = "cmbReportCity";
            cmbReportCity.Size = new Size(214, 32);
            cmbReportCity.TabIndex = 1;
            // 
            // cmbMonth
            // 
            cmbMonth.Font = new Font("Tahoma", 12F);
            cmbMonth.FormattingEnabled = true;
            cmbMonth.Items.AddRange(new object[] { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" });
            cmbMonth.Location = new Point(397, 129);
            cmbMonth.Name = "cmbMonth";
            cmbMonth.Size = new Size(222, 32);
            cmbMonth.TabIndex = 2;
            // 
            // btnGenerate
            // 
            btnGenerate.BackColor = Color.FromArgb(255, 128, 255);
            btnGenerate.FlatStyle = FlatStyle.Popup;
            btnGenerate.Font = new Font("SimSun-ExtG", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnGenerate.ForeColor = Color.FromArgb(255, 255, 128);
            btnGenerate.Location = new Point(303, 182);
            btnGenerate.Name = "btnGenerate";
            btnGenerate.Size = new Size(194, 34);
            btnGenerate.TabIndex = 3;
            btnGenerate.Text = "GENERATE REPORT";
            btnGenerate.UseVisualStyleBackColor = false;
            btnGenerate.Click += btnGenerate_Click;
            // 
            // btnExportPDF
            // 
            btnExportPDF.BackColor = Color.FromArgb(255, 192, 128);
            btnExportPDF.FlatStyle = FlatStyle.Flat;
            btnExportPDF.Font = new Font("Trebuchet MS", 12F, FontStyle.Bold);
            btnExportPDF.ForeColor = SystemColors.ControlLightLight;
            btnExportPDF.Location = new Point(69, 469);
            btnExportPDF.Name = "btnExportPDF";
            btnExportPDF.Size = new Size(250, 41);
            btnExportPDF.TabIndex = 9;
            btnExportPDF.Text = "EXPORT TO PDF";
            btnExportPDF.UseVisualStyleBackColor = false;
            btnExportPDF.Click += btnExportPDF_Click;
            // 
            // btnBack
            // 
            btnBack.BackColor = Color.FromArgb(255, 192, 128);
            btnBack.FlatStyle = FlatStyle.Flat;
            btnBack.Font = new Font("Trebuchet MS", 12F, FontStyle.Bold);
            btnBack.ForeColor = SystemColors.ControlLightLight;
            btnBack.Location = new Point(364, 469);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(373, 41);
            btnBack.TabIndex = 11;
            btnBack.Text = "BACK TO DASHBOARD";
            btnBack.UseVisualStyleBackColor = false;
            btnBack.Click += btnBack_Click;
            // 
            // rtbReport
            // 
            rtbReport.Font = new Font("Verdana", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            rtbReport.Location = new Point(12, 235);
            rtbReport.Name = "rtbReport";
            rtbReport.Size = new Size(781, 218);
            rtbReport.TabIndex = 12;
            rtbReport.Text = "";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(255, 224, 192);
            label1.Font = new Font("Times New Roman", 12F, FontStyle.Bold);
            label1.Location = new Point(197, 79);
            label1.Name = "label1";
            label1.Size = new Size(103, 23);
            label1.TabIndex = 13;
            label1.Text = "Select City";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.FromArgb(255, 224, 192);
            label2.Font = new Font("Times New Roman", 12F, FontStyle.Bold);
            label2.Location = new Point(460, 79);
            label2.Name = "label2";
            label2.Size = new Size(122, 23);
            label2.TabIndex = 14;
            label2.Text = "Select Month";
            // 
            // FormReports
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlDark;
            ClientSize = new Size(805, 530);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(rtbReport);
            Controls.Add(btnBack);
            Controls.Add(btnExportPDF);
            Controls.Add(btnGenerate);
            Controls.Add(cmbMonth);
            Controls.Add(cmbReportCity);
            Controls.Add(lblHeading);
            Name = "FormReports";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Sustainability Reports – Climate Impact Analysis";
            Load += FormReports_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblHeading;
        private ComboBox cmbReportCity;
        private ComboBox cmbMonth;
        private Button btnGenerate;
        private Button btnExportPDF;
        private Button btnBack;
        private RichTextBox rtbReport;
        private Label label1;
        private Label label2;
    }
}