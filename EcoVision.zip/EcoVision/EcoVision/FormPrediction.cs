﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace EcoVision
{
    public partial class FormPrediction : Form
    {
        string connectionString =
        "Server=(localdb)\\MSSQLLocalDB;Database=PollutionDB;Trusted_Connection=True;";
        public FormPrediction()
        {
            InitializeComponent();
        }

        private void btnTrain_Click(object sender, EventArgs e)
        {
            MessageBox.Show("AI Model Training Completed (Demo Mode).");
        }

        private void btnPredict_Click(object sender, EventArgs e)
        {
            if (cmbPredictCity.Text == "")
            {
                MessageBox.Show("Select a city.");
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                string query = @"SELECT TOP 10 AQI 
                         FROM PollutionData
                         WHERE City = @City
                         ORDER BY RecordedDate DESC";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@City", cmbPredictCity.Text);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                if (dt.Rows.Count < 3)
                {
                    MessageBox.Show("Not enough historical data.");
                    return;
                }

                // Reverse to chronological order
                dt.DefaultView.Sort = "AQI ASC";
                dt = dt.DefaultView.ToTable();

                List<double> values = new List<double>();

                foreach (DataRow row in dt.Rows)
                    values.Add(Convert.ToDouble(row["AQI"]));

                double weightedAvg = 0;
                double totalWeight = 0;

                for (int i = 0; i < values.Count; i++)
                {
                    double weight = i + 1; // recent values get more weight
                    weightedAvg += values[i] * weight;
                    totalWeight += weight;
                }

                weightedAvg /= totalWeight;

                // Trend calculation
                double trend = values[values.Count - 1] - values[0];

                // Volatility
                double variance = 0;
                foreach (double val in values)
                    variance += Math.Pow(val - weightedAvg, 2);

                variance /= values.Count;
                double volatility = Math.Sqrt(variance);

                // Prediction Table
                DataTable predictionTable = new DataTable();
                predictionTable.Columns.Add("Date");
                predictionTable.Columns.Add("Predicted AQI");

                chartPrediction.Series.Clear();
                chartPrediction.ChartAreas.Clear();
                chartPrediction.ChartAreas.Add(new System.Windows.Forms.DataVisualization.Charting.ChartArea());

                var series = new System.Windows.Forms.DataVisualization.Charting.Series("Forecast");
                series.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
                series.BorderWidth = 3;

                double baseValue = weightedAvg;

                for (int i = 1; i <= 7; i++)
                {
                    double predicted = baseValue + (trend * 0.1 * i) + (volatility * 0.05);

                    predictionTable.Rows.Add(
                        DateTime.Now.AddDays(i).ToShortDateString(),
                        predicted.ToString("0")
                    );

                    series.Points.AddXY(DateTime.Now.AddDays(i), predicted);
                }

                dgvPrediction.DataSource = predictionTable;
                chartPrediction.Series.Add(series);

                chartPrediction.ChartAreas[0].AxisX.LabelStyle.Format = "dd-MMM";
                chartPrediction.ChartAreas[0].AxisX.Title = "Date";
                chartPrediction.ChartAreas[0].AxisY.Title = "Predicted AQI";
                chartPrediction.Titles.Clear();
                chartPrediction.Titles.Add("7-Day AQI Forecast");

                // Risk Level
                if (baseValue > 200)
                {
                    lblRisk.Text = "Forecasted Risk Level: High";
                    lblRisk.ForeColor = Color.Red;
                }
                else if (baseValue > 100)
                {
                    lblRisk.Text = "Forecasted Risk Level: Moderate";
                    lblRisk.ForeColor = Color.Orange;
                }
                else
                {
                    lblRisk.Text = "Forecasted Risk Level: Low";
                    lblRisk.ForeColor = Color.Green;
                }

                // Confidence Score
                double confidence = 100 - (volatility / baseValue * 100);
                lblRisk.Text += "  |  Confidence: " + confidence.ToString("0") + "%";
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            FormDashboard dashboard = new FormDashboard();
            dashboard.Show();
            this.Close();
        }

        private void FormPrediction_Load(object sender, EventArgs e)
        {

        }
    }
}
