﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace EcoVision
{
    public partial class FormDataEntry : Form
    {
        string connectionString = "Server=(localdb)\\MSSQLLocalDB;Database=PollutionDB;Trusted_Connection=True;";
        private double CalculateAQI(double pm25)
        {
            if (pm25 <= 50) return pm25 * 1;
            else if (pm25 <= 100) return pm25 * 1.5;
            else if (pm25 <= 200) return pm25 * 2;
            else return pm25 * 3;
        }


        private void ResetForm()
        {
            cmbCity.SelectedIndex = -1;
            txtArea.Clear();
            txtPM25.Clear();
            txtPM10.Clear();
            txtNO2.Clear();
            txtSO2.Clear();
            txtCO.Clear();
            txtTemp.Clear();
            txtHumidity.Clear();
            lblAQIResult.Text = "Calculated AQI: ---";
        }
        public FormDataEntry()
        {
            InitializeComponent();
        }

        private void FormDataEntry_Load(object sender, EventArgs e)
        {

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            double pm25 = Convert.ToDouble(txtPM25.Text);

            double aqi = CalculateAQI(pm25);

            lblAQIResult.Text = "Calculated AQI: " + aqi.ToString("0.00");

            if (aqi <= 50)
                lblAQIResult.ForeColor = Color.Green;
            else if (aqi <= 100)
                lblAQIResult.ForeColor = Color.Orange;
            else
                lblAQIResult.ForeColor = Color.Red;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                string query = @"INSERT INTO PollutionData 
        (City, Area, PM25, PM10, NO2, SO2, CO, Temperature, Humidity, AQI, RecordedDate)
        VALUES (@City,@Area,@PM25,@PM10,@NO2,@SO2,@CO,@Temp,@Humidity,@AQI,@Date)";

                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@City", cmbCity.Text);
                cmd.Parameters.AddWithValue("@Area", txtArea.Text);
                cmd.Parameters.AddWithValue("@PM25", Convert.ToDouble(txtPM25.Text));
                cmd.Parameters.AddWithValue("@PM10", Convert.ToDouble(txtPM10.Text));
                cmd.Parameters.AddWithValue("@NO2", Convert.ToDouble(txtNO2.Text));
                cmd.Parameters.AddWithValue("@SO2", Convert.ToDouble(txtSO2.Text));
                cmd.Parameters.AddWithValue("@CO", Convert.ToDouble(txtCO.Text));
                cmd.Parameters.AddWithValue("@Temp", Convert.ToDouble(txtTemp.Text));
                cmd.Parameters.AddWithValue("@Humidity", Convert.ToDouble(txtHumidity.Text));
                cmd.Parameters.AddWithValue("@AQI", Convert.ToDouble(lblAQIResult.Text.Replace("Calculated AQI: ", "")));
                cmd.Parameters.AddWithValue("@Date", dtpDate.Value);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Pollution Data Saved Successfully!");
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            ResetForm();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            FormDashboard dashboard = new FormDashboard();
            dashboard.Show();
            this.Close();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void txtArea_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
