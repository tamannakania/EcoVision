﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Properties;

namespace EcoVision
{
    public partial class FormReports : Form
    {
        string connectionString =
"Server=(localdb)\\MSSQLLocalDB;Database=PollutionDB;Trusted_Connection=True;";
        public FormReports()
        {
            InitializeComponent();
        }

        private double CalculateScore(double avgAQI)
        {
            if (avgAQI <= 50) return 95;
            if (avgAQI <= 100) return 80;
            if (avgAQI <= 150) return 60;
            if (avgAQI <= 200) return 40;
            return 20;
        }

        private void FormReports_Load(object sender, EventArgs e)
        {

        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                string query = @"SELECT RecordedDate, AQI 
                         FROM PollutionData
                         WHERE City = @City
                         ORDER BY RecordedDate";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@City", cmbReportCity.Text);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("No data found.");
                    return;
                }

                double avg = Convert.ToDouble(dt.Compute("AVG(AQI)", ""));
                double max = Convert.ToDouble(dt.Compute("MAX(AQI)", ""));
                double min = Convert.ToDouble(dt.Compute("MIN(AQI)", ""));

                string report = "SUSTAINABILITY REPORT\n\n";
                report += "City: " + cmbReportCity.Text + "\n\n";
                report += "Average AQI: " + avg.ToString("0") + "\n";
                report += "Highest AQI: " + max.ToString("0") + "\n";
                report += "Lowest AQI: " + min.ToString("0") + "\n\n";

                if (avg > 200)
                    report += "Status: Critical Pollution Level\n";
                else if (avg > 100)
                    report += "Status: Moderate Pollution Level\n";
                else
                    report += "Status: Acceptable Air Quality\n";

                rtbReport.Text = report;
            }

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            FormDashboard dashboard = new FormDashboard();
            dashboard.Show();
            this.Close();
        }

        private void btnExportPDF_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "PDF File|*.pdf";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                using (PdfWriter writer = new PdfWriter(sfd.FileName))
                using (PdfDocument pdf = new PdfDocument(writer))
                using (Document document = new Document(pdf))
                {
                    document.Add(new Paragraph(rtbReport.Text));
                }

                MessageBox.Show("PDF Exported Successfully!");
            }
        }

        private void lblHeading_Click(object sender, EventArgs e)
        {

        }
    }
}
