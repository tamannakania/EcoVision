﻿namespace EcoVision
{
    partial class FormPrediction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            lblHeading = new Label();
            cmbPredictCity = new ComboBox();
            btnPredict = new Button();
            dgvPrediction = new DataGridView();
            btnBack = new Button();
            lblRisk = new Label();
            chartPrediction = new System.Windows.Forms.DataVisualization.Charting.Chart();
            ((System.ComponentModel.ISupportInitialize)dgvPrediction).BeginInit();
            ((System.ComponentModel.ISupportInitialize)chartPrediction).BeginInit();
            SuspendLayout();
            // 
            // lblHeading
            // 
            lblHeading.AutoSize = true;
            lblHeading.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblHeading.Location = new Point(91, 9);
            lblHeading.Name = "lblHeading";
            lblHeading.Size = new Size(640, 41);
            lblHeading.TabIndex = 0;
            lblHeading.Text = "Artificial Intelligence Based AQI Forecasting";
            // 
            // cmbPredictCity
            // 
            cmbPredictCity.BackColor = SystemColors.ActiveCaption;
            cmbPredictCity.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cmbPredictCity.FormattingEnabled = true;
            cmbPredictCity.Items.AddRange(new object[] { "Bangalore", "Delhi", "Mumbai", "Chennai", "Hyderabad", "Kolkata", "Pune", "Ahmedabad" });
            cmbPredictCity.Location = new Point(243, 67);
            cmbPredictCity.Name = "cmbPredictCity";
            cmbPredictCity.Size = new Size(262, 31);
            cmbPredictCity.TabIndex = 1;
            // 
            // btnPredict
            // 
            btnPredict.BackColor = Color.FromArgb(255, 192, 192);
            btnPredict.FlatStyle = FlatStyle.Flat;
            btnPredict.Font = new Font("Sylfaen", 10.8F, FontStyle.Bold);
            btnPredict.Location = new Point(243, 115);
            btnPredict.Name = "btnPredict";
            btnPredict.Size = new Size(262, 29);
            btnPredict.TabIndex = 3;
            btnPredict.Text = "PREDICT NEXT 7 DAYS";
            btnPredict.UseVisualStyleBackColor = false;
            btnPredict.Click += btnPredict_Click;
            // 
            // dgvPrediction
            // 
            dgvPrediction.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvPrediction.Location = new Point(26, 206);
            dgvPrediction.Name = "dgvPrediction";
            dgvPrediction.RowHeadersWidth = 51;
            dgvPrediction.Size = new Size(322, 256);
            dgvPrediction.TabIndex = 4;
            // 
            // btnBack
            // 
            btnBack.BackColor = Color.FromArgb(255, 192, 192);
            btnBack.FlatStyle = FlatStyle.Flat;
            btnBack.Font = new Font("Sylfaen", 10.8F, FontStyle.Bold);
            btnBack.Location = new Point(243, 483);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(262, 29);
            btnBack.TabIndex = 7;
            btnBack.Text = "BACK TO DASHBOARD";
            btnBack.UseVisualStyleBackColor = false;
            btnBack.Click += btnBack_Click;
            // 
            // lblRisk
            // 
            lblRisk.AutoSize = true;
            lblRisk.Font = new Font("Rockwell", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblRisk.Location = new Point(314, 158);
            lblRisk.Name = "lblRisk";
            lblRisk.Size = new Size(98, 20);
            lblRisk.TabIndex = 8;
            lblRisk.Text = "Risk Level";
            // 
            // chartPrediction
            // 
            chartArea1.Name = "ChartArea1";
            chartPrediction.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            chartPrediction.Legends.Add(legend1);
            chartPrediction.Location = new Point(405, 206);
            chartPrediction.Name = "chartPrediction";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            chartPrediction.Series.Add(series1);
            chartPrediction.Size = new Size(279, 256);
            chartPrediction.TabIndex = 9;
            chartPrediction.Text = "chart1";
            // 
            // FormPrediction
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 255, 192);
            ClientSize = new Size(749, 544);
            Controls.Add(chartPrediction);
            Controls.Add(lblRisk);
            Controls.Add(btnBack);
            Controls.Add(dgvPrediction);
            Controls.Add(btnPredict);
            Controls.Add(cmbPredictCity);
            Controls.Add(lblHeading);
            Name = "FormPrediction";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "AI AQI Prediction – Climate Forecast Engine";
            Load += FormPrediction_Load;
            ((System.ComponentModel.ISupportInitialize)dgvPrediction).EndInit();
            ((System.ComponentModel.ISupportInitialize)chartPrediction).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblHeading;
        private ComboBox cmbPredictCity;
        private Button btnPredict;
        private DataGridView dgvPrediction;
        private Button btnBack;
        private Label lblRisk;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartPrediction;
    }
}