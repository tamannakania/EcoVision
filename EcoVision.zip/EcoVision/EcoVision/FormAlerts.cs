﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace EcoVision
{
    public partial class FormAlerts : Form
    {
        string connectionString =
        "Server=(localdb)\\MSSQLLocalDB;Database=PollutionDB;Trusted_Connection=True;";

        private void LoadAlertHistory()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                string query = "SELECT City, AQI, AlertMessage, AlertDate FROM Alerts ORDER BY AlertDate DESC";

                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dgvAlerts.DataSource = dt;



                foreach (DataGridViewRow row in dgvAlerts.Rows)
                {
                    if (row.Cells["AQI"].Value == null) continue;

                    double val = Convert.ToDouble(row.Cells["AQI"].Value);

                    if (val > 200)
                        row.DefaultCellStyle.BackColor = Color.LightCoral;
                    else if (val > 100)
                        row.DefaultCellStyle.BackColor = Color.LightYellow;
                }
            }
        }

        private void SaveAlert(string city, double aqi, string message)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                string insertQuery = @"INSERT INTO Alerts
                                       (City, AQI, AlertMessage, AlertDate)
                                       VALUES (@City,@AQI,@Message,@Date)";

                SqlCommand insertCmd = new SqlCommand(insertQuery, con);
                insertCmd.Parameters.AddWithValue("@City", city);
                insertCmd.Parameters.AddWithValue("@AQI", aqi);
                insertCmd.Parameters.AddWithValue("@Message", message);
                insertCmd.Parameters.AddWithValue("@Date", DateTime.Now);

                insertCmd.ExecuteNonQuery();
            }
        }

        public FormAlerts()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void FormAlerts_Load(object sender, EventArgs e)
        {
            LoadAlertHistory();
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                // Get latest pollution record
                string query = @"SELECT TOP 1 City, AQI
                                 FROM PollutionData
                                 ORDER BY RecordedDate DESC";

                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader reader = cmd.ExecuteReader();

                if (!reader.Read())
                {
                    MessageBox.Show("No pollution data found.");
                    return;
                }

                string city = reader["City"].ToString();
                double aqi = Convert.ToDouble(reader["AQI"]);

                reader.Close();

                string message = "";

                if (aqi > 300)
                    message = "SEVERE ALERT in " + city;
                else if (aqi > 200)
                    message = "VERY UNHEALTHY AIR in " + city;
                else if (aqi > 150)
                    message = "UNHEALTHY AIR in " + city;
                else
                {
                    lblAlertStatus.Text = "Air Quality Safe";
                    lblAlertStatus.ForeColor = Color.Green;
                    return;
                }

                lblAlertStatus.Text = message;
                lblAlertStatus.ForeColor = Color.Red;

                SaveAlert(city, aqi, message);
            }

            LoadAlertHistory();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            FormDashboard dashboard = new FormDashboard();
            dashboard.Show();
            this.Close();
        }
    }
}
