﻿namespace EcoVision
{
    partial class FormRegister
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblHeading = new Label();
            lblEmail = new Label();
            lblPassword = new Label();
            lblRole = new Label();
            lblFullName = new Label();
            txtFullName = new TextBox();
            txtEmail = new TextBox();
            txtPassword = new TextBox();
            cmbRole = new ComboBox();
            btnCreate = new Button();
            btnBack = new Button();
            SuspendLayout();
            // 
            // lblHeading
            // 
            lblHeading.AutoSize = true;
            lblHeading.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblHeading.Location = new Point(107, 9);
            lblHeading.Name = "lblHeading";
            lblHeading.Size = new Size(615, 41);
            lblHeading.TabIndex = 0;
            lblHeading.Text = "Create Environmental Monitoring Account";
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.BackColor = Color.PapayaWhip;
            lblEmail.Font = new Font("Segoe UI Symbol", 12F, FontStyle.Bold);
            lblEmail.Location = new Point(89, 150);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(147, 28);
            lblEmail.TabIndex = 1;
            lblEmail.Text = "Email Address";
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.BackColor = Color.PapayaWhip;
            lblPassword.Font = new Font("Segoe UI Symbol", 12F, FontStyle.Bold);
            lblPassword.Location = new Point(89, 198);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new Size(170, 28);
            lblPassword.TabIndex = 2;
            lblPassword.Text = "Create Password";
            // 
            // lblRole
            // 
            lblRole.AutoSize = true;
            lblRole.BackColor = Color.PapayaWhip;
            lblRole.Font = new Font("Segoe UI Symbol", 12F, FontStyle.Bold);
            lblRole.Location = new Point(89, 255);
            lblRole.Name = "lblRole";
            lblRole.Size = new Size(119, 28);
            lblRole.TabIndex = 3;
            lblRole.Text = "Select Role";
            // 
            // lblFullName
            // 
            lblFullName.AutoSize = true;
            lblFullName.BackColor = Color.PapayaWhip;
            lblFullName.Font = new Font("Segoe UI Symbol", 12F, FontStyle.Bold);
            lblFullName.Location = new Point(89, 99);
            lblFullName.Name = "lblFullName";
            lblFullName.Size = new Size(109, 28);
            lblFullName.TabIndex = 5;
            lblFullName.Text = "Full Name";
            // 
            // txtFullName
            // 
            txtFullName.BackColor = SystemColors.ActiveCaption;
            txtFullName.Font = new Font("Segoe UI Symbol", 10.8F);
            txtFullName.Location = new Point(289, 92);
            txtFullName.Name = "txtFullName";
            txtFullName.Size = new Size(375, 31);
            txtFullName.TabIndex = 6;
            // 
            // txtEmail
            // 
            txtEmail.BackColor = SystemColors.ActiveCaption;
            txtEmail.Font = new Font("Segoe UI Symbol", 10.8F);
            txtEmail.Location = new Point(289, 143);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(375, 31);
            txtEmail.TabIndex = 7;
            // 
            // txtPassword
            // 
            txtPassword.BackColor = SystemColors.ActiveCaption;
            txtPassword.Font = new Font("Segoe UI Symbol", 10.8F);
            txtPassword.Location = new Point(289, 191);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(375, 31);
            txtPassword.TabIndex = 9;
            // 
            // cmbRole
            // 
            cmbRole.BackColor = SystemColors.ActiveCaption;
            cmbRole.Font = new Font("Segoe UI Symbol", 10.8F);
            cmbRole.FormattingEnabled = true;
            cmbRole.Items.AddRange(new object[] { "Environmental Analyst", "Research Student", "Government Officer", "NGO Representative", "Municipal Officer", "Public User" });
            cmbRole.Location = new Point(289, 247);
            cmbRole.Name = "cmbRole";
            cmbRole.Size = new Size(375, 33);
            cmbRole.TabIndex = 10;
            // 
            // btnCreate
            // 
            btnCreate.BackColor = Color.Tan;
            btnCreate.FlatStyle = FlatStyle.Flat;
            btnCreate.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            btnCreate.Location = new Point(153, 343);
            btnCreate.Name = "btnCreate";
            btnCreate.Size = new Size(194, 68);
            btnCreate.TabIndex = 11;
            btnCreate.Text = "CREATE ACCOUNT";
            btnCreate.UseVisualStyleBackColor = false;
            btnCreate.Click += btnCreate_Click;
            // 
            // btnBack
            // 
            btnBack.BackColor = Color.Tan;
            btnBack.FlatStyle = FlatStyle.Flat;
            btnBack.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            btnBack.Location = new Point(390, 343);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(194, 68);
            btnBack.TabIndex = 12;
            btnBack.Text = "BACK TO LOGIN";
            btnBack.UseVisualStyleBackColor = false;
            btnBack.Click += btnBack_Click;
            // 
            // FormRegister
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Silver;
            ClientSize = new Size(800, 450);
            Controls.Add(btnBack);
            Controls.Add(btnCreate);
            Controls.Add(cmbRole);
            Controls.Add(txtPassword);
            Controls.Add(txtEmail);
            Controls.Add(txtFullName);
            Controls.Add(lblFullName);
            Controls.Add(lblRole);
            Controls.Add(lblPassword);
            Controls.Add(lblEmail);
            Controls.Add(lblHeading);
            Name = "FormRegister";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Register – Climate Monitoring Portal";
            Load += FormRegister_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblHeading;
        private Label lblEmail;
        private Label lblPassword;
        private Label lblRole;
        private Label lblFullName;
        private TextBox txtFullName;
        private TextBox txtEmail;
        private TextBox txtPassword;
        private ComboBox cmbRole;
        private Button btnCreate;
        private Button btnBack;
    }
}