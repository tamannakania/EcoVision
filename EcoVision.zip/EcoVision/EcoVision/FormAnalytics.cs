﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using System.Windows.Forms.DataVisualization.Charting;

namespace EcoVision
{
    public partial class FormAnalytics : Form
    {
        string connectionString =
     "Server=(localdb)\\MSSQLLocalDB;Database=PollutionDB;Trusted_Connection=True;";

        private void LoadAQITrendChart(DataTable dt)
        {
            chartAQITrend.Series.Clear();
            chartAQITrend.ChartAreas.Clear();
            chartAQITrend.ChartAreas.Add(new ChartArea());

            Series series = new Series("AQI Trend");
            series.ChartType = SeriesChartType.Line;
            series.BorderWidth = 3;
            series.Color = Color.DarkBlue;
            series.XValueType = ChartValueType.Date;

            foreach (DataRow row in dt.Rows)
            {
                series.Points.AddXY(
                    Convert.ToDateTime(row["RecordedDate"]),
                    Convert.ToDouble(row["AQI"])
                );
            }

            chartAQITrend.Series.Add(series);

            chartAQITrend.ChartAreas[0].AxisX.LabelStyle.Format = "dd-MMM";
            chartAQITrend.ChartAreas[0].AxisX.Title = "Date";
            chartAQITrend.ChartAreas[0].AxisY.Title = "AQI Level";
            chartAQITrend.Titles.Clear();
            chartAQITrend.Titles.Add("AQI Trend Over Time");
        }

        private void LoadPollutantChart(DataTable dt)
        {
            chartPollutants.Series.Clear();
            chartPollutants.ChartAreas.Clear();
            chartPollutants.ChartAreas.Add(new ChartArea());

            double avgPM25 = Convert.ToDouble(dt.Compute("AVG(PM25)", ""));
            double avgPM10 = Convert.ToDouble(dt.Compute("AVG(PM10)", ""));
            double avgNO2 = Convert.ToDouble(dt.Compute("AVG(NO2)", ""));
            double avgSO2 = Convert.ToDouble(dt.Compute("AVG(SO2)", ""));
            double avgCO = Convert.ToDouble(dt.Compute("AVG(CO)", ""));

            Series series = new Series("Average Pollutants");
            series.ChartType = SeriesChartType.Column;
            series.IsValueShownAsLabel = true;

            series.Points.AddXY("PM2.5", avgPM25);
            series.Points.AddXY("PM10", avgPM10);
            series.Points.AddXY("NO2", avgNO2);
            series.Points.AddXY("SO2", avgSO2);
            series.Points.AddXY("CO", avgCO);

            chartPollutants.Series.Add(series);
            chartPollutants.Titles.Clear();
            chartPollutants.Titles.Add("Average Pollutant Levels");
        }

        private void LoadPieChart(DataTable dt)
        {
            chartPie.Series.Clear();
            chartPie.ChartAreas.Clear();
            chartPie.ChartAreas.Add(new ChartArea());

            double avgPM25 = Convert.ToDouble(dt.Compute("AVG(PM25)", ""));
            double avgPM10 = Convert.ToDouble(dt.Compute("AVG(PM10)", ""));
            double avgNO2 = Convert.ToDouble(dt.Compute("AVG(NO2)", ""));
            double avgSO2 = Convert.ToDouble(dt.Compute("AVG(SO2)", ""));
            double avgCO = Convert.ToDouble(dt.Compute("AVG(CO)", ""));

            Series series = new Series("Pollution Composition");
            series.ChartType = SeriesChartType.Pie;
            series.IsValueShownAsLabel = true;
            series["PieLabelStyle"] = "Outside";

            series.Points.AddXY("PM2.5", avgPM25);
            series.Points.AddXY("PM10", avgPM10);
            series.Points.AddXY("NO2", avgNO2);
            series.Points.AddXY("SO2", avgSO2);
            series.Points.AddXY("CO", avgCO);

            chartPie.Series.Add(series);
            chartPie.Titles.Clear();
            chartPie.Titles.Add("Pollution Composition Breakdown");
        }


        public FormAnalytics()
        {
            InitializeComponent();
        }
        private void FormAnalytics_Load(object sender, EventArgs e)
        {
            dtpFrom.Value = DateTime.Now.AddDays(-7);
            dtpTo.Value = DateTime.Now;
        }
        private void btnLoadAnalytics_Click(object sender, EventArgs e)
        {
            if (cmbFilterCity.Text == "")
            {
                MessageBox.Show("Please select a city.");
                return;
            }

            if (dtpFrom.Value > dtpTo.Value)
            {
                MessageBox.Show("From date cannot be greater than To date.");
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                string query = @"SELECT RecordedDate, AQI, PM25, PM10, NO2, SO2, CO
                         FROM PollutionData
                         WHERE City = @City
                         AND RecordedDate BETWEEN @From AND @To
                         ORDER BY RecordedDate";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@City", cmbFilterCity.Text);
                cmd.Parameters.AddWithValue("@From", dtpFrom.Value.Date);
                cmd.Parameters.AddWithValue("@To", dtpTo.Value.Date);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("No data found for selected filters.");
                    return;
                }

                LoadAQITrendChart(dt);      // 🔥 First chart
                LoadPollutantChart(dt);     // 🔥 Second chart
                LoadPieChart(dt);           // 🔥 Third chart
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            FormDashboard dashboard = new FormDashboard();
            dashboard.Show();
            this.Close();
        }

    }
}
