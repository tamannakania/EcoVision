﻿namespace EcoVision
{
    partial class FormDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panelTop = new Panel();
            lblSystemTitle = new Label();
            panelSideMenu = new Panel();
            btnLogout = new Button();
            btnReports = new Button();
            btnAlerts = new Button();
            btnPrediction = new Button();
            btnAnalytics = new Button();
            btnDataEntry = new Button();
            panelOverview1 = new Panel();
            lblAQIValue = new Label();
            lblAQITitle = new Label();
            panelOverview2 = new Panel();
            lblHotZoneValue = new Label();
            lblHotZone = new Label();
            panelOverview3 = new Panel();
            lblTrendValue = new Label();
            lblTrend = new Label();
            panelOverview4 = new Panel();
            lblScoreValue = new Label();
            lblScore = new Label();
            panelTop.SuspendLayout();
            panelSideMenu.SuspendLayout();
            panelOverview1.SuspendLayout();
            panelOverview2.SuspendLayout();
            panelOverview3.SuspendLayout();
            panelOverview4.SuspendLayout();
            SuspendLayout();
            // 
            // panelTop
            // 
            panelTop.BackColor = SystemColors.ActiveCaptionText;
            panelTop.Controls.Add(lblSystemTitle);
            panelTop.Location = new Point(35, 12);
            panelTop.Name = "panelTop";
            panelTop.Size = new Size(924, 99);
            panelTop.TabIndex = 0;
            // 
            // lblSystemTitle
            // 
            lblSystemTitle.AutoSize = true;
            lblSystemTitle.BackColor = SystemColors.ButtonFace;
            lblSystemTitle.Font = new Font("Segoe UI Historic", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblSystemTitle.Location = new Point(147, 29);
            lblSystemTitle.Name = "lblSystemTitle";
            lblSystemTitle.Size = new Size(632, 41);
            lblSystemTitle.TabIndex = 0;
            lblSystemTitle.Text = "Urban Pollution Intelligence Control Center";
            lblSystemTitle.Click += lblSystemTitle_Click;
            // 
            // panelSideMenu
            // 
            panelSideMenu.BackColor = Color.Gray;
            panelSideMenu.Controls.Add(btnLogout);
            panelSideMenu.Controls.Add(btnReports);
            panelSideMenu.Controls.Add(btnAlerts);
            panelSideMenu.Controls.Add(btnPrediction);
            panelSideMenu.Controls.Add(btnAnalytics);
            panelSideMenu.Controls.Add(btnDataEntry);
            panelSideMenu.Location = new Point(35, 141);
            panelSideMenu.Name = "panelSideMenu";
            panelSideMenu.Size = new Size(256, 413);
            panelSideMenu.TabIndex = 1;
            // 
            // btnLogout
            // 
            btnLogout.BackColor = Color.Red;
            btnLogout.FlatStyle = FlatStyle.Flat;
            btnLogout.Font = new Font("Georgia", 10.8F, FontStyle.Bold);
            btnLogout.Location = new Point(15, 351);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new Size(218, 44);
            btnLogout.TabIndex = 7;
            btnLogout.Text = "LOGOUT";
            btnLogout.UseVisualStyleBackColor = false;
            btnLogout.Click += btnLogout_Click;
            // 
            // btnReports
            // 
            btnReports.BackColor = Color.WhiteSmoke;
            btnReports.FlatStyle = FlatStyle.Flat;
            btnReports.Font = new Font("Georgia", 10.8F, FontStyle.Bold);
            btnReports.Location = new Point(15, 248);
            btnReports.Name = "btnReports";
            btnReports.Size = new Size(218, 55);
            btnReports.TabIndex = 6;
            btnReports.Text = "Sustainability Reports";
            btnReports.UseVisualStyleBackColor = false;
            btnReports.Click += btnReports_Click;
            // 
            // btnAlerts
            // 
            btnAlerts.BackColor = Color.WhiteSmoke;
            btnAlerts.FlatStyle = FlatStyle.Flat;
            btnAlerts.Font = new Font("Georgia", 10.8F, FontStyle.Bold);
            btnAlerts.Location = new Point(15, 191);
            btnAlerts.Name = "btnAlerts";
            btnAlerts.Size = new Size(218, 51);
            btnAlerts.TabIndex = 2;
            btnAlerts.Text = "Smart Alerts Center";
            btnAlerts.UseVisualStyleBackColor = false;
            btnAlerts.Click += btnAlerts_Click;
            // 
            // btnPrediction
            // 
            btnPrediction.BackColor = Color.WhiteSmoke;
            btnPrediction.FlatStyle = FlatStyle.Flat;
            btnPrediction.Font = new Font("Georgia", 10.8F, FontStyle.Bold);
            btnPrediction.Location = new Point(15, 132);
            btnPrediction.Name = "btnPrediction";
            btnPrediction.Size = new Size(218, 53);
            btnPrediction.TabIndex = 3;
            btnPrediction.Text = "AI AQI Prediction";
            btnPrediction.UseVisualStyleBackColor = false;
            btnPrediction.Click += btnPrediction_Click;
            // 
            // btnAnalytics
            // 
            btnAnalytics.BackColor = Color.WhiteSmoke;
            btnAnalytics.FlatStyle = FlatStyle.Flat;
            btnAnalytics.Font = new Font("Georgia", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAnalytics.Location = new Point(15, 76);
            btnAnalytics.Name = "btnAnalytics";
            btnAnalytics.Size = new Size(218, 50);
            btnAnalytics.TabIndex = 4;
            btnAnalytics.Text = "Analytics Dashboard";
            btnAnalytics.UseVisualStyleBackColor = false;
            btnAnalytics.Click += btnAnalytics_Click;
            // 
            // btnDataEntry
            // 
            btnDataEntry.BackColor = Color.WhiteSmoke;
            btnDataEntry.FlatStyle = FlatStyle.Flat;
            btnDataEntry.Font = new Font("Georgia", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDataEntry.Location = new Point(15, 17);
            btnDataEntry.Name = "btnDataEntry";
            btnDataEntry.Size = new Size(218, 53);
            btnDataEntry.TabIndex = 5;
            btnDataEntry.Text = "Add Pollution Data";
            btnDataEntry.UseVisualStyleBackColor = false;
            btnDataEntry.Click += btnDataEntry_Click;
            // 
            // panelOverview1
            // 
            panelOverview1.BackColor = SystemColors.GradientInactiveCaption;
            panelOverview1.Controls.Add(lblAQIValue);
            panelOverview1.Controls.Add(lblAQITitle);
            panelOverview1.Location = new Point(312, 141);
            panelOverview1.Name = "panelOverview1";
            panelOverview1.Size = new Size(647, 87);
            panelOverview1.TabIndex = 2;
            // 
            // lblAQIValue
            // 
            lblAQIValue.AutoSize = true;
            lblAQIValue.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAQIValue.Location = new Point(338, 34);
            lblAQIValue.Name = "lblAQIValue";
            lblAQIValue.Size = new Size(64, 25);
            lblAQIValue.TabIndex = 1;
            lblAQIValue.Text = "AQI---";
            // 
            // lblAQITitle
            // 
            lblAQITitle.AutoSize = true;
            lblAQITitle.Font = new Font("Segoe UI Symbol", 10.8F, FontStyle.Bold);
            lblAQITitle.Location = new Point(91, 34);
            lblAQITitle.Name = "lblAQITitle";
            lblAQITitle.Size = new Size(195, 25);
            lblAQITitle.TabIndex = 0;
            lblAQITitle.Text = "Current Average AQI";
            // 
            // panelOverview2
            // 
            panelOverview2.BackColor = SystemColors.GradientInactiveCaption;
            panelOverview2.Controls.Add(lblHotZoneValue);
            panelOverview2.Controls.Add(lblHotZone);
            panelOverview2.Location = new Point(312, 248);
            panelOverview2.Name = "panelOverview2";
            panelOverview2.Size = new Size(647, 87);
            panelOverview2.TabIndex = 3;
            // 
            // lblHotZoneValue
            // 
            lblHotZoneValue.AutoSize = true;
            lblHotZoneValue.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold);
            lblHotZoneValue.Location = new Point(338, 34);
            lblHotZoneValue.Name = "lblHotZoneValue";
            lblHotZoneValue.Size = new Size(75, 23);
            lblHotZoneValue.TabIndex = 8;
            lblHotZoneValue.Text = "Area: ---";
            lblHotZoneValue.Click += lblHotZoneValue_Click;
            // 
            // lblHotZone
            // 
            lblHotZone.AutoSize = true;
            lblHotZone.Font = new Font("Segoe UI Symbol", 10.8F, FontStyle.Bold);
            lblHotZone.Location = new Point(91, 34);
            lblHotZone.Name = "lblHotZone";
            lblHotZone.Size = new Size(182, 25);
            lblHotZone.TabIndex = 0;
            lblHotZone.Text = "Most Polluted Area";
            // 
            // panelOverview3
            // 
            panelOverview3.BackColor = SystemColors.GradientInactiveCaption;
            panelOverview3.Controls.Add(lblTrendValue);
            panelOverview3.Controls.Add(lblTrend);
            panelOverview3.Location = new Point(312, 357);
            panelOverview3.Name = "panelOverview3";
            panelOverview3.Size = new Size(647, 87);
            panelOverview3.TabIndex = 4;
            // 
            // lblTrendValue
            // 
            lblTrendValue.AutoSize = true;
            lblTrendValue.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold);
            lblTrendValue.Location = new Point(338, 32);
            lblTrendValue.Name = "lblTrendValue";
            lblTrendValue.Size = new Size(38, 23);
            lblTrendValue.TabIndex = 7;
            lblTrendValue.Text = "----";
            // 
            // lblTrend
            // 
            lblTrend.AutoSize = true;
            lblTrend.Font = new Font("Segoe UI Symbol", 10.8F, FontStyle.Bold);
            lblTrend.Location = new Point(91, 34);
            lblTrend.Name = "lblTrend";
            lblTrend.Size = new Size(208, 25);
            lblTrend.TabIndex = 0;
            lblTrend.Text = "Pollution Trend Status";
            // 
            // panelOverview4
            // 
            panelOverview4.BackColor = SystemColors.GradientInactiveCaption;
            panelOverview4.Controls.Add(lblScoreValue);
            panelOverview4.Controls.Add(lblScore);
            panelOverview4.Location = new Point(312, 467);
            panelOverview4.Name = "panelOverview4";
            panelOverview4.Size = new Size(647, 87);
            panelOverview4.TabIndex = 5;
            // 
            // lblScoreValue
            // 
            lblScoreValue.AutoSize = true;
            lblScoreValue.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold);
            lblScoreValue.Location = new Point(338, 34);
            lblScoreValue.Name = "lblScoreValue";
            lblScoreValue.Size = new Size(82, 23);
            lblScoreValue.TabIndex = 6;
            lblScoreValue.Text = "Score: ---";
            // 
            // lblScore
            // 
            lblScore.AutoSize = true;
            lblScore.Font = new Font("Segoe UI Symbol", 10.8F, FontStyle.Bold);
            lblScore.Location = new Point(91, 34);
            lblScore.Name = "lblScore";
            lblScore.Size = new Size(185, 25);
            lblScore.TabIndex = 0;
            lblScore.Text = "Sustainability Score";
            // 
            // FormDashboard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Info;
            ClientSize = new Size(992, 581);
            Controls.Add(panelOverview4);
            Controls.Add(panelOverview3);
            Controls.Add(panelOverview2);
            Controls.Add(panelOverview1);
            Controls.Add(panelSideMenu);
            Controls.Add(panelTop);
            Name = "FormDashboard";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Main Dashboard – Pollution Intelligence Control Center";
            Load += FormDashboard_Load;
            panelTop.ResumeLayout(false);
            panelTop.PerformLayout();
            panelSideMenu.ResumeLayout(false);
            panelOverview1.ResumeLayout(false);
            panelOverview1.PerformLayout();
            panelOverview2.ResumeLayout(false);
            panelOverview2.PerformLayout();
            panelOverview3.ResumeLayout(false);
            panelOverview3.PerformLayout();
            panelOverview4.ResumeLayout(false);
            panelOverview4.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelTop;
        private Label lblSystemTitle;
        private Panel panelSideMenu;
        private Button btnDataEntry;
        private Button btnAlerts;
        private Button btnPrediction;
        private Button btnAnalytics;
        private Button btnLogout;
        private Button btnReports;
        private Panel panelOverview1;
        private Label lblAQITitle;
        private Panel panelOverview2;
        private Label lblHotZone;
        private Panel panelOverview3;
        private Label lblTrend;
        private Panel panelOverview4;
        private Label lblScore;
        private Label lblAQIValue;
        private Label lblHotZoneValue;
        private Label lblTrendValue;
        private Label lblScoreValue;
    }
}