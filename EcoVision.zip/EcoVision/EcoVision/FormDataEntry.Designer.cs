﻿namespace EcoVision
{
    partial class FormDataEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblHeading = new Label();
            lblArea = new Label();
            lblCity = new Label();
            lblDate = new Label();
            cmbCity = new ComboBox();
            txtArea = new TextBox();
            txtSO2 = new TextBox();
            txtPM25 = new TextBox();
            txtNO2 = new TextBox();
            txtPM10 = new TextBox();
            dtpDate = new DateTimePicker();
            grpPollutants = new GroupBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            btnCalculate = new Button();
            txtHumidity = new TextBox();
            txtTemp = new TextBox();
            txtCO = new TextBox();
            lblAQIResult = new Label();
            btnSave = new Button();
            btnReset = new Button();
            btnBack = new Button();
            grpPollutants.SuspendLayout();
            SuspendLayout();
            // 
            // lblHeading
            // 
            lblHeading.AutoSize = true;
            lblHeading.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblHeading.Location = new Point(182, 11);
            lblHeading.Name = "lblHeading";
            lblHeading.Size = new Size(564, 41);
            lblHeading.TabIndex = 0;
            lblHeading.Text = "Environmental Data Collection Module";
            // 
            // lblArea
            // 
            lblArea.AutoSize = true;
            lblArea.Font = new Font("Goudy Old Style", 12F, FontStyle.Bold);
            lblArea.Location = new Point(56, 166);
            lblArea.Name = "lblArea";
            lblArea.Size = new Size(104, 23);
            lblArea.TabIndex = 1;
            lblArea.Text = "Area Name";
            // 
            // lblCity
            // 
            lblCity.AutoSize = true;
            lblCity.Font = new Font("Goudy Old Style", 12F, FontStyle.Bold);
            lblCity.Location = new Point(56, 104);
            lblCity.Name = "lblCity";
            lblCity.Size = new Size(96, 23);
            lblCity.TabIndex = 3;
            lblCity.Text = "Select City";
            // 
            // lblDate
            // 
            lblDate.AutoSize = true;
            lblDate.Font = new Font("Goudy Old Style", 12F, FontStyle.Bold);
            lblDate.Location = new Point(56, 223);
            lblDate.Name = "lblDate";
            lblDate.Size = new Size(49, 23);
            lblDate.TabIndex = 4;
            lblDate.Text = "Date";
            // 
            // cmbCity
            // 
            cmbCity.BackColor = SystemColors.ActiveCaption;
            cmbCity.FormattingEnabled = true;
            cmbCity.Items.AddRange(new object[] { "Bangalore", "Delhi", "Mumbai", "Chennai", "Hyderabad", "Kolkata", "Pune", "Ahmedabad" });
            cmbCity.Location = new Point(182, 95);
            cmbCity.Name = "cmbCity";
            cmbCity.Size = new Size(306, 31);
            cmbCity.TabIndex = 6;
            // 
            // txtArea
            // 
            txtArea.BackColor = Color.FromArgb(255, 255, 192);
            txtArea.Location = new Point(182, 158);
            txtArea.Name = "txtArea";
            txtArea.Size = new Size(306, 30);
            txtArea.TabIndex = 7;
            txtArea.TextChanged += txtArea_TextChanged;
            // 
            // txtSO2
            // 
            txtSO2.BackColor = Color.FromArgb(255, 192, 128);
            txtSO2.Font = new Font("Palatino Linotype", 10.8F);
            txtSO2.Location = new Point(306, 52);
            txtSO2.Name = "txtSO2";
            txtSO2.Size = new Size(141, 32);
            txtSO2.TabIndex = 8;
            // 
            // txtPM25
            // 
            txtPM25.BackColor = Color.FromArgb(255, 192, 128);
            txtPM25.Font = new Font("Palatino Linotype", 10.8F);
            txtPM25.Location = new Point(7, 52);
            txtPM25.Name = "txtPM25";
            txtPM25.Size = new Size(141, 32);
            txtPM25.TabIndex = 9;
            // 
            // txtNO2
            // 
            txtNO2.BackColor = Color.FromArgb(255, 192, 128);
            txtNO2.Font = new Font("Palatino Linotype", 10.8F);
            txtNO2.Location = new Point(7, 188);
            txtNO2.Name = "txtNO2";
            txtNO2.Size = new Size(141, 32);
            txtNO2.TabIndex = 10;
            // 
            // txtPM10
            // 
            txtPM10.BackColor = Color.FromArgb(255, 192, 128);
            txtPM10.Font = new Font("Palatino Linotype", 10.8F);
            txtPM10.Location = new Point(6, 114);
            txtPM10.Name = "txtPM10";
            txtPM10.Size = new Size(141, 32);
            txtPM10.TabIndex = 11;
            // 
            // dtpDate
            // 
            dtpDate.Location = new Point(182, 215);
            dtpDate.Name = "dtpDate";
            dtpDate.Size = new Size(306, 30);
            dtpDate.TabIndex = 12;
            // 
            // grpPollutants
            // 
            grpPollutants.BackColor = Color.FromArgb(192, 192, 255);
            grpPollutants.Controls.Add(label1);
            grpPollutants.Controls.Add(label2);
            grpPollutants.Controls.Add(label3);
            grpPollutants.Controls.Add(label4);
            grpPollutants.Controls.Add(label5);
            grpPollutants.Controls.Add(label6);
            grpPollutants.Controls.Add(label7);
            grpPollutants.Controls.Add(btnCalculate);
            grpPollutants.Controls.Add(txtHumidity);
            grpPollutants.Controls.Add(txtTemp);
            grpPollutants.Controls.Add(txtCO);
            grpPollutants.Controls.Add(txtPM25);
            grpPollutants.Controls.Add(txtPM10);
            grpPollutants.Controls.Add(txtSO2);
            grpPollutants.Controls.Add(txtNO2);
            grpPollutants.Location = new Point(524, 78);
            grpPollutants.Name = "grpPollutants";
            grpPollutants.Size = new Size(477, 292);
            grpPollutants.TabIndex = 13;
            grpPollutants.TabStop = false;
            grpPollutants.Text = "Atmospheric Pollutant Inputs";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Goudy Old Style", 12F, FontStyle.Bold);
            label1.Location = new Point(306, 162);
            label1.Name = "label1";
            label1.Size = new Size(119, 23);
            label1.TabIndex = 21;
            label1.Text = "Temperature";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Goudy Old Style", 12F, FontStyle.Bold);
            label2.Location = new Point(307, 88);
            label2.Name = "label2";
            label2.Size = new Size(160, 23);
            label2.TabIndex = 22;
            label2.Text = "Carbon Monoxide";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Goudy Old Style", 12F, FontStyle.Bold);
            label3.Location = new Point(307, 26);
            label3.Name = "label3";
            label3.Size = new Size(132, 23);
            label3.TabIndex = 23;
            label3.Text = "Sulfur Dioxide";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Goudy Old Style", 12F, FontStyle.Bold);
            label4.Location = new Point(9, 230);
            label4.Name = "label4";
            label4.Size = new Size(91, 23);
            label4.TabIndex = 24;
            label4.Text = "Humidity";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Goudy Old Style", 12F, FontStyle.Bold);
            label5.Location = new Point(9, 162);
            label5.Name = "label5";
            label5.Size = new Size(155, 23);
            label5.TabIndex = 25;
            label5.Text = "Nitrogen Dioxide";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Goudy Old Style", 12F, FontStyle.Bold);
            label6.Location = new Point(7, 88);
            label6.Name = "label6";
            label6.Size = new Size(114, 23);
            label6.TabIndex = 26;
            label6.Text = "PM (10 mm)";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Goudy Old Style", 12F, FontStyle.Bold);
            label7.Location = new Point(7, 26);
            label7.Name = "label7";
            label7.Size = new Size(114, 23);
            label7.TabIndex = 27;
            label7.Text = "PM (25 mm)";
            label7.Click += label7_Click;
            // 
            // btnCalculate
            // 
            btnCalculate.BackColor = Color.FromArgb(192, 255, 192);
            btnCalculate.Font = new Font("Sitka Display", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCalculate.Location = new Point(307, 252);
            btnCalculate.Name = "btnCalculate";
            btnCalculate.Size = new Size(140, 34);
            btnCalculate.TabIndex = 16;
            btnCalculate.Text = "CALCULATE AQI";
            btnCalculate.UseVisualStyleBackColor = false;
            btnCalculate.Click += btnCalculate_Click;
            // 
            // txtHumidity
            // 
            txtHumidity.BackColor = Color.FromArgb(255, 192, 128);
            txtHumidity.Font = new Font("Palatino Linotype", 10.8F);
            txtHumidity.Location = new Point(6, 256);
            txtHumidity.Name = "txtHumidity";
            txtHumidity.Size = new Size(141, 32);
            txtHumidity.TabIndex = 15;
            // 
            // txtTemp
            // 
            txtTemp.BackColor = Color.FromArgb(255, 192, 128);
            txtTemp.Font = new Font("Palatino Linotype", 10.8F);
            txtTemp.Location = new Point(307, 188);
            txtTemp.Name = "txtTemp";
            txtTemp.Size = new Size(141, 32);
            txtTemp.TabIndex = 13;
            // 
            // txtCO
            // 
            txtCO.BackColor = Color.FromArgb(255, 192, 128);
            txtCO.Font = new Font("Palatino Linotype", 10.8F);
            txtCO.Location = new Point(306, 114);
            txtCO.Name = "txtCO";
            txtCO.Size = new Size(141, 32);
            txtCO.TabIndex = 12;
            // 
            // lblAQIResult
            // 
            lblAQIResult.AutoSize = true;
            lblAQIResult.Font = new Font("Kristen ITC", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAQIResult.Location = new Point(391, 417);
            lblAQIResult.Name = "lblAQIResult";
            lblAQIResult.Size = new Size(217, 28);
            lblAQIResult.TabIndex = 17;
            lblAQIResult.Text = "Calculated AQI: ---";
            // 
            // btnSave
            // 
            btnSave.BackColor = Color.FromArgb(255, 192, 192);
            btnSave.FlatStyle = FlatStyle.Flat;
            btnSave.Font = new Font("Perpetua Titling MT", 10.8F, FontStyle.Bold);
            btnSave.Location = new Point(92, 473);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(106, 34);
            btnSave.TabIndex = 18;
            btnSave.Text = "SAVE DATA";
            btnSave.UseVisualStyleBackColor = false;
            btnSave.Click += btnSave_Click;
            // 
            // btnReset
            // 
            btnReset.BackColor = Color.FromArgb(255, 192, 192);
            btnReset.FlatStyle = FlatStyle.Flat;
            btnReset.Font = new Font("Perpetua Titling MT", 10.8F, FontStyle.Bold);
            btnReset.Location = new Point(442, 473);
            btnReset.Name = "btnReset";
            btnReset.Size = new Size(106, 34);
            btnReset.TabIndex = 19;
            btnReset.Text = "RESET";
            btnReset.UseVisualStyleBackColor = false;
            btnReset.Click += btnReset_Click;
            // 
            // btnBack
            // 
            btnBack.BackColor = Color.FromArgb(255, 192, 192);
            btnBack.FlatStyle = FlatStyle.Flat;
            btnBack.Font = new Font("Perpetua Titling MT", 10.8F, FontStyle.Bold);
            btnBack.Location = new Point(698, 473);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(274, 34);
            btnBack.TabIndex = 20;
            btnBack.Text = "BACK TO DASHBOARD";
            btnBack.UseVisualStyleBackColor = false;
            btnBack.Click += btnBack_Click;
            // 
            // FormDataEntry
            // 
            AutoScaleDimensions = new SizeF(9F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlDark;
            ClientSize = new Size(1044, 550);
            Controls.Add(btnBack);
            Controls.Add(btnReset);
            Controls.Add(btnSave);
            Controls.Add(lblAQIResult);
            Controls.Add(grpPollutants);
            Controls.Add(dtpDate);
            Controls.Add(txtArea);
            Controls.Add(cmbCity);
            Controls.Add(lblDate);
            Controls.Add(lblCity);
            Controls.Add(lblArea);
            Controls.Add(lblHeading);
            Font = new Font("Segoe UI Historic", 10.2F);
            Name = "FormDataEntry";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Pollution Data Entry – Environmental Monitoring";
            Load += FormDataEntry_Load;
            grpPollutants.ResumeLayout(false);
            grpPollutants.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblHeading;
        private Label lblArea;
        private Label lblCity;
        private Label lblDate;
        private ComboBox cmbCity;
        private TextBox txtArea;
        private TextBox txtSO2;
        private TextBox txtPM25;
        private TextBox txtNO2;
        private TextBox txtPM10;
        private DateTimePicker dtpDate;
        private GroupBox grpPollutants;
        private Button btnCalculate;
        private TextBox txtHumidity;
        private TextBox txtTemp;
        private TextBox txtCO;
        private Label lblAQIResult;
        private Button btnSave;
        private Button btnReset;
        private Button btnBack;
        private Label label7;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
    }
}