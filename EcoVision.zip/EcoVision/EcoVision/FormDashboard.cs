﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace EcoVision
{
    public partial class FormDashboard : Form
    {
        string connectionString =
"Server=(localdb)\\MSSQLLocalDB;Database=PollutionDB;Trusted_Connection=True;";
        public FormDashboard()
        {
            InitializeComponent();
        }

        private void LoadDashboardData()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();

                    // Check if table has data
                    string checkQuery = "SELECT COUNT(*) FROM PollutionData";
                    SqlCommand checkCmd = new SqlCommand(checkQuery, con);
                    int count = (int)checkCmd.ExecuteScalar();

                    if (count == 0)
                    {
                        lblAQIValue.Text = "AQI: No Data";
                        lblHotZoneValue.Text = "No Data";
                        lblTrendValue.Text = "No Data";
                        lblScoreValue.Text = "0%";
                        return;
                    }

                    // 1️⃣ Average AQI
                    string avgQuery = "SELECT AVG(AQI) FROM PollutionData";
                    SqlCommand avgCmd = new SqlCommand(avgQuery, con);
                    object avgResult = avgCmd.ExecuteScalar();

                    double avgAQI = Convert.ToDouble(avgResult);
                    lblAQIValue.Text = "AQI: " + avgAQI.ToString("0");

                    if (avgAQI <= 100)
                        lblAQIValue.ForeColor = Color.Green;
                    else if (avgAQI <= 200)
                        lblAQIValue.ForeColor = Color.Orange;
                    else
                        lblAQIValue.ForeColor = Color.Red;

                    // 2️⃣ Most Polluted City
                    string maxQuery = @"SELECT TOP 1 City 
                                        FROM PollutionData 
                                        ORDER BY AQI DESC";

                    SqlCommand maxCmd = new SqlCommand(maxQuery, con);
                    object cityResult = maxCmd.ExecuteScalar();

                    lblHotZoneValue.Text = cityResult.ToString();

                    // 3️⃣ Trend Calculation
                    string trendQuery = @"SELECT TOP 2 AQI 
                                          FROM PollutionData 
                                          ORDER BY RecordedDate DESC";

                    SqlCommand trendCmd = new SqlCommand(trendQuery, con);
                    SqlDataReader trendReader = trendCmd.ExecuteReader();

                    double latest = 0, previous = 0;

                    if (trendReader.Read())
                        latest = Convert.ToDouble(trendReader["AQI"]);

                    if (trendReader.Read())
                        previous = Convert.ToDouble(trendReader["AQI"]);

                    trendReader.Close();

                    if (latest > previous)
                    {
                        lblTrendValue.Text = "Increasing 📈";
                        lblTrendValue.ForeColor = Color.Red;
                    }
                    else
                    {
                        lblTrendValue.Text = "Improving 📉";
                        lblTrendValue.ForeColor = Color.Green;
                    }

                    // 4️⃣ Sustainability Score
                    double score = CalculateSustainabilityScore(avgAQI);
                    lblScoreValue.Text = score.ToString("0") + "%";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading dashboard: " + ex.Message);
            }
        }

        private double CalculateSustainabilityScore(double avgAQI)
        {
            if (avgAQI <= 50) return 95;
            if (avgAQI <= 100) return 80;
            if (avgAQI <= 150) return 60;
            if (avgAQI <= 200) return 40;
            return 20;
        }

        private double CalculateSustainabilityScore(SqlConnection con)
        {
            string query = "SELECT AVG(AQI) FROM PollutionData";
            SqlCommand cmd = new SqlCommand(query, con);

            object result = cmd.ExecuteScalar();

            if (result == DBNull.Value)
                return 0;

            double avgAQI = Convert.ToDouble(result);

            // Simple scoring logic
            if (avgAQI <= 50) return 95;
            if (avgAQI <= 100) return 80;
            if (avgAQI <= 150) return 60;
            if (avgAQI <= 200) return 40;
            return 20;
        }

        private void lblSystemTitle_Click(object sender, EventArgs e)
        {

        }

        private void FormDashboard_Load(object sender, EventArgs e)
        {
            LoadDashboardData();
        }

        private void btnAnalytics_Click(object sender, EventArgs e)
        {
            FormAnalytics analytics = new FormAnalytics();
            analytics.Show();
            this.Hide();
        }

        private void btnPrediction_Click(object sender, EventArgs e)
        {
            FormPrediction prediction = new FormPrediction();
            prediction.Show();
            this.Hide();
        }

        private void btnAlerts_Click(object sender, EventArgs e)
        {
            FormAlerts alerts = new FormAlerts();
            alerts.Show();
            this.Hide();
        }

        private void btnReports_Click(object sender, EventArgs e)
        {
            FormReports reports = new FormReports();
            reports.Show();
            this.Hide();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            FormLogin login = new FormLogin();
            login.Show();
            this.Close();
        }

        private void btnDataEntry_Click(object sender, EventArgs e)
        {
            FormDataEntry dataEntry = new FormDataEntry();
            dataEntry.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lblHotZoneValue_Click(object sender, EventArgs e)
        {

        }
    }
}
