﻿namespace EcoVision
{
    partial class FormLogin
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTitle = new Label();
            lblSubtitle = new Label();
            panelLogin = new Panel();
            btnLogin = new Button();
            btnRegister = new Button();
            txtPassword = new TextBox();
            lblPassword = new Label();
            txtUsername = new TextBox();
            label3 = new Label();
            lblUsername = new Label();
            btnExit = new Button();
            lblQuote = new Label();
            panelLogin.SuspendLayout();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTitle.Location = new Point(158, 9);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(698, 41);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "Welcome to Urban Pollution Intelligence System";
            // 
            // lblSubtitle
            // 
            lblSubtitle.AutoSize = true;
            lblSubtitle.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            lblSubtitle.Location = new Point(313, 50);
            lblSubtitle.Name = "lblSubtitle";
            lblSubtitle.Size = new Size(365, 28);
            lblSubtitle.TabIndex = 1;
            lblSubtitle.Text = "Empowering Data-Driven Climate Action";
            // 
            // panelLogin
            // 
            panelLogin.BackColor = SystemColors.ActiveCaptionText;
            panelLogin.Controls.Add(btnLogin);
            panelLogin.Controls.Add(btnRegister);
            panelLogin.Controls.Add(txtPassword);
            panelLogin.Controls.Add(lblPassword);
            panelLogin.Controls.Add(txtUsername);
            panelLogin.Controls.Add(label3);
            panelLogin.Controls.Add(lblUsername);
            panelLogin.Location = new Point(146, 90);
            panelLogin.Name = "panelLogin";
            panelLogin.Size = new Size(727, 238);
            panelLogin.TabIndex = 2;
            // 
            // btnLogin
            // 
            btnLogin.BackColor = SystemColors.Info;
            btnLogin.FlatStyle = FlatStyle.Flat;
            btnLogin.Font = new Font("Segoe UI Historic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLogin.Location = new Point(167, 138);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(109, 55);
            btnLogin.TabIndex = 9;
            btnLogin.Text = "LOGIN";
            btnLogin.UseVisualStyleBackColor = false;
            btnLogin.Click += btnLogin_Click;
            // 
            // btnRegister
            // 
            btnRegister.BackColor = SystemColors.Info;
            btnRegister.FlatStyle = FlatStyle.Flat;
            btnRegister.Font = new Font("Segoe UI Historic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnRegister.Location = new Point(328, 138);
            btnRegister.Name = "btnRegister";
            btnRegister.Size = new Size(274, 55);
            btnRegister.TabIndex = 8;
            btnRegister.Text = "REGISTER NEW ACCOUNT";
            btnRegister.UseVisualStyleBackColor = false;
            btnRegister.Click += btnRegister_Click;
            // 
            // txtPassword
            // 
            txtPassword.BackColor = SystemColors.ActiveCaption;
            txtPassword.Location = new Point(292, 70);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(310, 27);
            txtPassword.TabIndex = 7;
            txtPassword.UseSystemPasswordChar = true;
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.BackColor = SystemColors.ActiveCaption;
            lblPassword.Font = new Font("Segoe UI Historic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblPassword.Location = new Point(167, 69);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new Size(94, 28);
            lblPassword.TabIndex = 3;
            lblPassword.Text = "Password";
            // 
            // txtUsername
            // 
            txtUsername.BackColor = SystemColors.ActiveCaption;
            txtUsername.Location = new Point(292, 28);
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(310, 27);
            txtUsername.TabIndex = 6;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(33, 77);
            label3.Name = "label3";
            label3.Size = new Size(50, 20);
            label3.TabIndex = 5;
            label3.Text = "label3";
            // 
            // lblUsername
            // 
            lblUsername.AutoSize = true;
            lblUsername.BackColor = SystemColors.ActiveCaption;
            lblUsername.Font = new Font("Segoe UI Historic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblUsername.Location = new Point(167, 28);
            lblUsername.Name = "lblUsername";
            lblUsername.Size = new Size(99, 28);
            lblUsername.TabIndex = 4;
            lblUsername.Text = "Username";
            // 
            // btnExit
            // 
            btnExit.BackColor = SystemColors.Info;
            btnExit.FlatStyle = FlatStyle.Flat;
            btnExit.Font = new Font("Segoe UI Symbol", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            btnExit.Location = new Point(402, 360);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(163, 62);
            btnExit.TabIndex = 3;
            btnExit.Text = "EXIT SYSTEM";
            btnExit.UseVisualStyleBackColor = false;
            btnExit.Click += btnExit_Click;
            // 
            // lblQuote
            // 
            lblQuote.AutoSize = true;
            lblQuote.Font = new Font("Segoe Script", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            lblQuote.Location = new Point(280, 446);
            lblQuote.Name = "lblQuote";
            lblQuote.Size = new Size(439, 36);
            lblQuote.TabIndex = 4;
            lblQuote.Text = "Clean Air is a Fundamental Right";
            // 
            // FormLogin
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLight;
            ClientSize = new Size(991, 501);
            Controls.Add(lblQuote);
            Controls.Add(btnExit);
            Controls.Add(panelLogin);
            Controls.Add(lblSubtitle);
            Controls.Add(lblTitle);
            Name = "FormLogin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Login – Urban Pollution Intelligence System";
            Load += FormLogin_Load;
            panelLogin.ResumeLayout(false);
            panelLogin.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTitle;
        private Label lblSubtitle;
        private Panel panelLogin;
        private Label lblPassword;
        private Label lblUsername;
        private Label label3;
        private TextBox txtUsername;
        private TextBox txtPassword;
        private Button btnLogin;
        private Button btnRegister;
        private Button btnExit;
        private Label lblQuote;
    }
}
